package com.LEGENO.ShareOurSchedule;

import java.io.Serializable;

public class ItemData implements Serializable {
    public String ID;
    public String Title;
    public String Time;
    public String Content;
}
